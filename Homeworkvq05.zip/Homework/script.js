function upDate(previewPic) {
    const image = document.getElementById("image");
    image.style.backgroundImage = `url(${previewPic.src})`;
    image.textContent = previewPic.alt;
}

function undo() {
    const image = document.getElementById("image");
    image.style.backgroundImage = "";
    image.textContent = "Hover over an image below to display here.";
}
